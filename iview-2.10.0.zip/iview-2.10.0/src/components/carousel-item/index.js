import CarouselItem from '../carousel/carousel-item.vue';

export default CarouselItem;