import Carousel from './carousel.vue';
import CarouselItem from './carousel-item.vue';

Carousel.Item = CarouselItem;
export default Carousel;