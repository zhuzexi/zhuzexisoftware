import Poptip from './poptip.vue';

export default Poptip;