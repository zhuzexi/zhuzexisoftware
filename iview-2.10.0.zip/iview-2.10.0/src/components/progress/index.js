import Progress from './progress.vue';
export default Progress;