import Tooltip from './tooltip.vue';

export default Tooltip;