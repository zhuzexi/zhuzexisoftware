import Submenu from '../menu/submenu.vue';

export default Submenu;