import Radio from './radio.vue';
import RadioGroup from './radio-group.vue';

Radio.Group = RadioGroup;
export default Radio;