import MenuItem from '../menu/menu-item.vue';

export default MenuItem;