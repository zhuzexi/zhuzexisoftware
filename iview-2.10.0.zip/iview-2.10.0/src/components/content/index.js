import Content from '../layout/content.vue';

export default Content; 