import locale from '../../locale/index';

export default locale.i18n;